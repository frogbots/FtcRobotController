package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Hardware;

import drivers.MaxSonarI2CXL;
import robotComponents.drivebase.SkyStoneDriveBase;

public class Globals {
    public static SkyStoneDriveBase driveBase;
    public static TrackingWheelIntegrator trackingWheelIntegrator;
    public static LinearOpMode opMode;
    public static LynxModule odoModule;
    public static Servo wobble;
    public static Servo ShooterAngle;
    public static DcMotorEx Shooter;
    public static DcMotor Intake;
    public static DcMotor IntakeTwo;
    public static Servo WArmR;
    public static Servo WArm;
    public static Servo WArmL;
    //public static Servo Tpusher;
    public static Servo Tbooper;
    public static Servo IntakeLift;
    public static MaxSonarI2CXL RightSonar;
    public static MaxSonarI2CXL Backsonar;
    public static MaxSonarI2CXL LeftSonar;
    public static double inch;
    public static SkyStoneDriveBase robot;
    public static boolean RingStack;
    public static double angle;



//sonar = hardwareMap.get(MaxSonarI2CXL.class, "RightSonar");

    public double DSStartPos = 20;

    public static double GetShootingAngle() {
        return angle;
    }

    public static void updateTracking()
    {
        LynxModule.BulkData bulkData = odoModule.getBulkData();

        int left = bulkData.getMotorCurrentPosition(0);
        int right = bulkData.getMotorCurrentPosition(1);
        int aux = bulkData.getMotorCurrentPosition(2);


        trackingWheelIntegrator.update(left, right, aux);
        opMode.telemetry.addData("X", trackingWheelIntegrator.getX());
        System.out.println(trackingWheelIntegrator.getX());
        opMode.telemetry.addData("Y", trackingWheelIntegrator.getY());
        opMode.telemetry.addData("wheelH", trackingWheelIntegrator.getHeading());
        opMode.telemetry.addData("ShooterAngle", + frogTeleOp.GetShootingAngle());
        opMode.telemetry.update();

        Globals.Shooter.setDirection(DcMotor.Direction.REVERSE);


    }
}
