package org.firstinspires.ftc.teamcode;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.openftc.easyopencv.OpenCvPipeline;

public class RingDetectionBlue extends OpenCvPipeline
{
    double OneRingThreshold = 1.035;
    double ThreeRingThreshold = 1.16;
    double Density;
    double ControlDensity;
    double RatioDensity;
    DropPositions Position;
    int width = 40;
    int hight = 35;
    Mat CutoutMat;
    Mat CutoutMat2;
    Mat YCrCb = new Mat();
    Mat Cr = new Mat();
    Point TopLeftPoint = new Point(210,155); // (0,0) is top left // 47 158
    Point BottomRightPoint = new Point(TopLeftPoint.x + width, TopLeftPoint.y + hight); // reminder to adjust the X val off of ultra sonic distance

    Point TopLeftPoint2 = new Point(215,205); // (0,0) is top left
    Point BottomRightPoint2 = new Point(TopLeftPoint.x + width, TopLeftPoint.y + hight);


    @Override
    public void init (Mat input) {
        Imgproc.cvtColor(input,YCrCb,Imgproc.COLOR_RGB2YCrCb);
        Core.extractChannel(YCrCb,Cr,1);
        CutoutMat = Cr.submat(new Rect(TopLeftPoint, BottomRightPoint));
        CutoutMat2 = Cr.submat(new Rect(TopLeftPoint2, BottomRightPoint2));


    }
    @Override
    public Mat processFrame(Mat input)
    {
        Imgproc.cvtColor(input,YCrCb,Imgproc.COLOR_RGB2YCrCb);
        Core.extractChannel(YCrCb,Cr,1);
        Imgproc.rectangle(
                input,
                TopLeftPoint,
                BottomRightPoint,
                new Scalar(0, 0, 255), 2);
        Density = (int) Core.mean(CutoutMat).val[0];
        Imgproc.rectangle(
                input,
                TopLeftPoint2,
                BottomRightPoint2,
                new Scalar(0, 0, 255), 2);
        ControlDensity = (int) Core.mean(CutoutMat2).val[0];
        return input;
    }
    public double GetLastDensity() {
        return Density;
    }
    public double GetLastControlDensity() {
        return ControlDensity;
    }
    public double GetLastRatioDensity() {
        return RatioDensity;
    }
    public DropPositions GetPosition() {
        RatioDensity = Density/ControlDensity;
        if (RatioDensity < OneRingThreshold) {
           Position = DropPositions.A;
        }
        if (RatioDensity > ThreeRingThreshold) {
            Position = DropPositions.C;
        }
        else if (RatioDensity > OneRingThreshold) {
            if (RatioDensity < ThreeRingThreshold)
            Position = DropPositions.B;
        }
        return Position;
    }
}