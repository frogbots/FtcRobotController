package org.firstinspires.ftc.teamcode;

public enum DropPositions {
    A,
    B,
    C,
}
