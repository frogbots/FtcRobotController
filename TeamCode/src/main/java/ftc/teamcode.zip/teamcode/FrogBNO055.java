/*
  public FrogBNO055(BNO055IMU external_imu) {
 }
  }
  package net.frogbots.skystone.drivers;
          import com.qualcomm.hardware.bosch.BNO055IMU;
         import net.frogbots.skystone.opmodes.auto.AbortAutoNowException;
         import net.frogbots.skystone.opmodes.auto.Globals;

         import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
         import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
         import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
         import org.firstinspires.ftc.robotcore.external.navigation.Orientation;

 public class FrogBNO055
  {
     private BNO055IMU imu;
  private float yaw, pitch, roll;
     private int numAttempts = 0;

     public FrogBNO055(BNO055IMU imu)
     {
         this.imu = imu;
     }

     public float pollAndGetYaw()
     {
         poll();
         return yaw;
     }

     public float pollAndGetPitch()
     {
         poll();
         return pitch;
     }

     public float pollAndGetRoll()
     {
         poll();
         return roll;
     }





     case 101:
                    // move Forward To B
                    tgPosition = 'B';
                    aX = 88*1700; // Inch times encoder per inch (1700)
                    Power = 1;
                    if (Power > 0) {
                        Power = 0.1 + (aX + lCountsTW)/aX;
                        frontLeft.setPower(Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(Power);
                        if (lCountsTW < -aX) {
                            Power = 0;
                            state = 102;
                        }
                    }
                    break;

                case 102:
                    // drop Wobble Goal
                    Power = 0;
                    frontLeft.setPower(Power);
                    frontRight.setPower(Power);
                    backLeft.setPower(Power);
                    backRight.setPower(Power);
                    sleep(1000);
                    autoDrop.setPosition(.5);
                    sleep(1000);
                    droppedWobble = true;
                    if (droppedWobble = true); state = 103;
                    break;

                case 103:
                    // move back
                    Power = 1;
                    if (Power > 0) {
                        Power = -0.1 + (aX1 + lCountsTW)/aX1;
                        frontLeft.setPower(Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(Power);
                        if (lCountsTW > -aX) {
                            Power = 0;
                            state = 104;
                        }
                    }
                    break;

                case 104:
                    // move to shoot
                    aX = 32000;
                    Power = 1;
                    if (Power > 0) {
                        Power = -0.1 + (aX + bCountsTW)/aX;
                        frontLeft.setPower(-Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(-Power);
                        if (lCountsTW > -aX) {
                            Power = 0;
                            state = 0;
                        }
                    }
                    break;

                case 201:
                    // move Forward to C
                    tgPosition = 'C';
                    aX = 112*1700;
                    Power = 1;
                    if (Power > 0) {
                        Power = 0.1 + (aX + lCountsTW)/aX;
                        frontLeft.setPower(Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(Power);
                        if (lCountsTW < -aX) {
                            Power = 0;
                            state = 202;
                        }
                    }
                    break;

                case 202:
                    // drop Wobble Goal
                    Power = 0;
                    frontLeft.setPower(Power);
                    frontRight.setPower(Power);
                    backLeft.setPower(Power);
                    backRight.setPower(Power);
                    sleep(1000);
                    autoDrop.setPosition(.5);
                    sleep(1000);
                    droppedWobble = true;
                    if (droppedWobble = true); state = 203;
                    break;

                case 203:
                    // move back
                    aX = 93500;
                    Power = 1;
                    if (Power > 0) {
                        Power = -0.1 + (aX + lCountsTW)/aX;
                        frontLeft.setPower(Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(Power);
                        if (lCountsTW > -aX) {
                            Power = 0;
                            state = 204;
                        }
                    }
                    break;

                case 204:
                    // move to shoot
                    aX = 32000;
                    Power = 1;
                    if (Power > 0) {
                        Power = -0.1 + (aX + bCountsTW)/aX;
                        frontLeft.setPower(-Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(-Power);
                        if (lCountsTW > -aX) {
                            Power = 0;
                            state = 0;
                        }
                    }
                    break;
 */

