package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.lynx.LynxDcMotorController;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.MovingStatistics;

import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvInternalCamera;

import control.AcceleratedGain;
import drivers.MaxSonarI2CXL;
import robotComponents.drivebase.SkyStoneDriveBase;
import trajectory.IntakeDown;
import trajectory.IntakeDownSlow;
import trajectory.IntakeDownSlowTwo;
import trajectory.IntakeDownTwo;
import trajectory.PickUpWobbleGoal;
import trajectory.PointApproach;
import trajectory.PrepareForTeleop;
import trajectory.RiseWG;
import trajectory.ShootPSOne;
import trajectory.ShootPSThree;
import trajectory.ShootPSTwo;
import trajectory.ShooterShotThreefar;
import trajectory.SleepAction;
import trajectory.Trajectory;
import trajectory.Waypoint;
import trajectory.WobbleDeployAction;
import trajectory.WobbleGoalDropTwo;

@Autonomous (preselectTeleOp="frogTeleOp")
public class BlueSideThreePFourShot extends LinearOpMode
{
    MovingStatistics movingStatistics = new MovingStatistics(300);

    long startLoop = 0;

    private DcMotor shooter;

    //private DcMotorEx FL;
    //private DcMotorEx FR;
    //private DcMotorEx RL;
    //private DcMotorEx RR;
    double DropX;
    double DropY;
    double DropHeading;
    double DropHeadingTwo;
    double DropXTwo;
    double DropYTwo;
    double FirstFeildMovementX;
    double FirstFeildMovmentY;
    double WaypointXTwoD;
    double WaypointYTwoD;
    double ParkY;
    double ParkX;
    double ShootY;
    double ShootX;
    double ShootH;
    double cmToInch = 0;
    public double inch = 0;
    OpenCvCamera phoneCam;
    public static boolean RingStack;


    TrackingWheelIntegrator trackingWheelIntegrator = new TrackingWheelIntegrator();

    LynxDcMotorController ctrl;
    LynxModule module;

    SkyStoneDriveBase skyStoneDriveBase;

    Trajectory trajectory;




    DropPositions position = DropPositions.B;

    void SetDropPositions(){
        if (position == DropPositions.A) {
            DropX = 5;
            DropY = 62;
            DropHeading = 0;
            DropHeadingTwo = -153;
            FirstFeildMovementX = 5;
            FirstFeildMovmentY = 30;
            DropXTwo = 6;
            DropYTwo = 58;
            WaypointXTwoD = 20;
            WaypointYTwoD = 30;
            RingStack = false;
            ParkY = 55;
            ParkX = DropXTwo;
            ShootY = DropYTwo;
            ShootX = DropXTwo;
            ShootH = DropHeadingTwo;
        }
        else if (position == DropPositions.B) {
            DropX = 24;
            DropY = 87;
            DropHeading = -24;
            DropHeadingTwo = 180;
            FirstFeildMovementX = 5;
            FirstFeildMovmentY = 50;
            DropXTwo = 22;
            DropYTwo = 82;
            RingStack = true;
            ShootX = -24;
            ShootY = 50;
            ShootH = 0;
            ParkY = 73;
            ParkX = DropXTwo;
        }
        else if (position == DropPositions.C) {
            DropX = 6;
            DropY = 108;
            DropHeading = 18;
            DropHeadingTwo = -180;
            FirstFeildMovementX = 5;
            FirstFeildMovmentY = 70;
            DropXTwo = 2;
            DropYTwo = 103;
            RingStack = true;
            ShootX = -24;
            ShootY = 50;
            ShootH = 0;
            ParkY = 73;
            ParkX = 41;
        }
    }

    @Override
    public void runOpMode() throws InterruptedException
    {

        trackingWheelIntegrator = new TrackingWheelIntegrator();

        module = (LynxModule) hardwareMap.get(LynxModule.class, "Expansion Hub 3");
        ctrl = hardwareMap.get(LynxDcMotorController.class, "Expansion Hub 3");

        skyStoneDriveBase = new SkyStoneDriveBase();
        skyStoneDriveBase.init(hardwareMap);
        skyStoneDriveBase.resetEncoders();
        skyStoneDriveBase.enableBrake(true);
        skyStoneDriveBase.enablePID();
        Globals.robot=skyStoneDriveBase;
        Globals.driveBase=skyStoneDriveBase;

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        phoneCam = OpenCvCameraFactory.getInstance().createInternalCamera(OpenCvInternalCamera.CameraDirection.FRONT, cameraMonitorViewId);
        RingDetectionBlue RingPipline = new RingDetectionBlue();
        phoneCam.setPipeline(RingPipline);
        phoneCam.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener()
        {
            @Override
            public void onOpened()
            {
                phoneCam.setViewportRenderingPolicy(OpenCvCamera.ViewportRenderingPolicy.OPTIMIZE_VIEW);
                phoneCam.startStreaming(320, 240, OpenCvCameraRotation.SIDEWAYS_LEFT);
            }
        });

        telemetry.setMsTransmissionInterval(50);

        Globals.LeftSonar = hardwareMap.get(MaxSonarI2CXL.class, "LeftSonar");
        Globals.opMode = this;
        Globals.trackingWheelIntegrator = trackingWheelIntegrator;
        Globals.odoModule = module;
        Globals.wobble = hardwareMap.get(Servo.class, "autoDrop");
        Globals.ShooterAngle = hardwareMap.get(Servo.class, "shooterAngle");
        Globals.Shooter= hardwareMap.get(DcMotorEx.class,"shooter");
        Globals.Intake=hardwareMap.get(DcMotor.class,"Intake");
        Globals.IntakeTwo=hardwareMap.get(DcMotor.class, "intakeTwo");
        Globals.WArmR=hardwareMap.get(Servo.class, "WArmR");
        Globals.WArmL=hardwareMap.get(Servo.class, "WArmL");
        Globals.WArm=hardwareMap.get(Servo.class, "WArm");
        Globals.Tbooper= hardwareMap.get(Servo.class, "Tbooper");
        //Globals.Tpusher= hardwareMap.get(Servo.class, "Tpusher");
        Globals.IntakeLift= hardwareMap.get(Servo.class, "intakeLift");

        Globals.Shooter.setDirection(DcMotor.Direction.REVERSE);

        Globals.ShooterAngle.setPosition(1);
        Globals.wobble.setPosition(.9);
        //Globals.IntakeLift.setPosition(1);
        Globals.Tbooper.setPosition(.15);
        Globals.IntakeLift.setPosition(.6);

        telemetry.setMsTransmissionInterval(20);
        cmToInch = Globals.LeftSonar.getDistanceSync();
        inch = cmToInch/2.54;
        telemetry.addData("Dist inch", inch+2);
        telemetry.addData("Position", RingPipline.GetPosition());
        telemetry.update();

        Globals.inch = inch;

        trackingWheelIntegrator.setFirstTrackingVal(inch,0);

        clearEnc();

        while (!isStopRequested() && !isStarted()) {
            position = RingPipline.GetPosition();
            telemetry.addData("Position", RingPipline.GetPosition());
            telemetry.addData("Dist inch", inch+1);
            telemetry.update();
        }
        SetDropPositions();
        if (position == DropPositions.A) {
            buildTrajectoryA();
        }
        if (position == DropPositions.B) {
            buildTrajectoryB();
        }
        if (position == DropPositions.C) {
            buildTrajectoryC();
        }
        trajectory.follow();
    }
    void clearEnc()
    {
        ctrl.setMotorMode(0, DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        ctrl.setMotorMode(1, DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        ctrl.setMotorMode(2, DcMotor.RunMode.STOP_AND_RESET_ENCODER);


        ctrl.setMotorMode(0, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ctrl.setMotorMode(1, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ctrl.setMotorMode(2, DcMotor.RunMode.RUN_WITHOUT_ENCODER);

    }

    public void buildTrajectoryA()
    {
        trajectory = new Trajectory.Builder()

               .addMovement(new Waypoint.Builder() // First Stright movment to Target position
                      .setTargetPosition(FirstFeildMovementX, FirstFeildMovmentY )
                      .setTargetHeading(0)
                      .setSpeed(1)
                      .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                      .setMovementThresh(1)
                      .setHeadingThreshold(0)
                      .build())
               .addMovement(new PointApproach.Builder() //Final Target position movment and Drop Wobble goal
                      .setTargetPosition(DropX,DropY)
                      .setMaxPower(0.95)
                      .setXyGain(.06)
                      .setTargetHeading(DropHeading)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.6)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new WobbleDeployAction()) // Drop Wobble goal
               .addMovement(new SleepAction(500))
               .addMovement(new PointApproach.Builder() //Move to Shoot PS1 right
                      .setTargetPosition(47.5,61)
                      .setMaxPower(0.85)
                      .setXyGain(.04)
                      .setTargetHeading(0)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.45)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new ShootPSOne())
               .addMovement(new SleepAction(200))
               .addMovement(new PointApproach.Builder() //Move to Shoot PS2 middle
                      .setTargetPosition(49,61)
                      .setMaxPower(0.85)
                      .setXyGain(.04)
                      .setTargetHeading(-5)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.45)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new ShootPSTwo())
               .addMovement(new SleepAction(200))
               .addMovement(new PointApproach.Builder() //Move to Shoot PS3 left
                      .setTargetPosition(50.5,61)
                      .setMaxPower(0.85)
                      .setXyGain(.04)
                      .setTargetHeading(-10)                                        // Movement to shot 3 into High goal
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.45)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new ShootPSThree())
               .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                      .setTargetPosition(40,24)
                      .setMaxPower(1)
                      .setXyGain(.04)
                      .setTargetHeading(0)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.45)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new RiseWG())
               .addMovement(new SleepAction(300))
               .addMovement(new PickUpWobbleGoal()) //PickUpWobbleGoal
               .addMovement(new PointApproach.Builder() //Move to Drop off point.
                      .setTargetPosition(DropXTwo,DropYTwo)
                      .setMaxPower(0.95)
                      .setXyGain(.08)
                      .setTargetHeading(DropHeadingTwo)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.8)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new WobbleGoalDropTwo()) // Drop Wobble goal
               .addMovement(new SleepAction(200))
               .addMovement(new PointApproach.Builder() //Move to Park
                      .setTargetPosition(ParkX,ParkY)
                      .setMaxPower(1)
                      .setXyGain(.1)
                      .setTargetHeading(0)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.9)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new PointApproach.Builder() //Move to Park
                      .setTargetPosition(22,73)
                      .setMaxPower(1)
                      .setXyGain(.1)
                      .setTargetHeading(0)
                      .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                      .setMaxTurnPower(0.9)
                      .setMovementThresh(1)
                      .setHeadingThreshold(2)
                      .stopMotorsOnDone(true)
                      .build())
               .addMovement(new PrepareForTeleop())
               .addMovement(new SleepAction(200))


        .build();
    }
    public void buildTrajectoryB()
    {
        trajectory = new Trajectory.Builder()

                .addMovement(new Waypoint.Builder() // First Stright movment to Target position
                        .setTargetPosition(FirstFeildMovementX, FirstFeildMovmentY )
                        .setTargetHeading(0)
                        .setSpeed(1)
                        .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .build())
                .addMovement(new PointApproach.Builder() //Final Target position movment and Drop Wobble goal
                        .setTargetPosition(DropX,DropY)
                        .setMaxPower(0.95)
                        .setXyGain(.06)
                        .setTargetHeading(DropHeading)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.6)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleDeployAction()) // Drop Wobble goal
                .addMovement(new SleepAction(500))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS1 right
                        .setTargetPosition(44,62)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSOne())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS2 middle
                        .setTargetPosition(47,62)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(-5)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSTwo())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS3 left
                        .setTargetPosition(49,62)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(-10)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSThree())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(40,24)
                        .setMaxPower(1)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new RiseWG())
                .addMovement(new SleepAction(300))
                .addMovement(new PickUpWobbleGoal()) //PickUpWobbleGoal
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(25,28)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new IntakeDownTwo())
                .addMovement(new SleepAction(1500))
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(25,30)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShooterShotThreefar())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Drop off point.
                        .setTargetPosition(DropXTwo,DropYTwo)
                        .setMaxPower(0.95)
                        .setXyGain(.08)
                        .setTargetHeading(DropHeadingTwo)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleGoalDropTwo()) // Drop Wobble goal
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Park
                        .setTargetPosition(ParkX,ParkY)
                        .setMaxPower(1)
                        .setXyGain(.1)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.9)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                /*.addMovement(new PointApproach.Builder() //Move to Park
                        .setTargetPosition(41,73)
                        .setMaxPower(1)
                        .setXyGain(.1)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.9)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())

                 */
                .addMovement(new PrepareForTeleop())
                .addMovement(new SleepAction(200))


                .build();
    }
    public void buildTrajectoryC()
    {
        trajectory = new Trajectory.Builder()

                .addMovement(new Waypoint.Builder() // First Stright movment to Target position
                        .setTargetPosition(FirstFeildMovementX, FirstFeildMovmentY )
                        .setTargetHeading(0)
                        .setSpeed(1)
                        .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .build())
                .addMovement(new PointApproach.Builder() //Final Target position movment and Drop Wobble goal
                        .setTargetPosition(DropX,DropY)
                        .setMaxPower(0.95)
                        .setXyGain(.06)
                        .setTargetHeading(DropHeading)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.6)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleDeployAction()) // Drop Wobble goal
                .addMovement(new SleepAction(500))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS1 right
                        .setTargetPosition(43.5,60)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSOne())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS2 middle
                        .setTargetPosition(46.5,60)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(-5)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSTwo())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS3 left
                        .setTargetPosition(47,60)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(-10)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSThree())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(42,24)
                        .setMaxPower(1)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new RiseWG())
                .addMovement(new SleepAction(100))
                .addMovement(new PickUpWobbleGoal()) //PickUpWobbleGoal
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(23,25.5)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new IntakeDown())
                .addMovement(new SleepAction(1000))
                .addMovement(new IntakeDownSlow())
                .addMovement(new SleepAction(2000))
                .addMovement(new ShooterShotThreefar())
                .addMovement(new SleepAction(100))
                .addMovement(new IntakeDownSlowTwo())
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(23,27)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new SleepAction(500))
                .addMovement(new IntakeDownTwo())
                .addMovement(new SleepAction(1000))
                .addMovement(new ShooterShotThreefar())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Drop off point.
                        .setTargetPosition(DropXTwo,DropYTwo)
                        .setMaxPower(0.95)
                        .setXyGain(.08)
                        .setTargetHeading(DropHeadingTwo)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleGoalDropTwo()) // Drop Wobble goal
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Park
                        .setTargetPosition(22,73)
                        .setMaxPower(1)
                        .setXyGain(.1)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.9)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new PrepareForTeleop())
                .addMovement(new SleepAction(200))

                .build();
    }
}
