package org.firstinspires.ftc.teamcode;


// import

import com.qualcomm.hardware.lynx.LynxDcMotorController;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
// import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.hardware.bosch.BNO055IMU;

import control.AcceleratedGain;
import drivers.MaxSonarI2CXL;
import robotComponents.drivebase.DriveTrain;
import robotComponents.drivebase.DriveTrainBase;
import trajectory.SMPSOverHeadOne;
import trajectory.SMPSOverHeadThree;
import trajectory.SMPSOverHeadTwo;
import trajectory.SleepAction;
import trajectory.StateMPointApproach;
import trajectory.StateMShooterShotThree;
import trajectory.StateMTrajectory;

// where is it
import control.MecanumDrive;
import robotComponents.drivebase.SkyStoneDriveBase;
import trajectory.StateMWaypoint;
import trajectory.Waypoint;
//

 //build it store
@TeleOp
public class frogTeleOp extends LinearOpMode {

    private BNO055IMU imu;
    private DcMotorEx FL;
    private DcMotorEx FR;
    private DcMotorEx RL;
    private DcMotorEx RR;
    private Servo autoDrop;
    private Servo shooterAngle;
    private DcMotor intake;
    private DcMotor intakeTwo;
    private DcMotor rightTW;
    private DcMotor leftTW;
    private DcMotor backTW;
    private DcMotorEx shooter;
    private Servo WArmR;
    private Servo WArmL;
    private Servo Tbooper;
    private Servo intakeLift;
    private int ITLPosiont;
    StateMTrajectory trajectory;
    SkyStoneDriveBase skyStoneDriveBase;
    double curretShooterSpeed;
    boolean ShooterUpToSpeed;
    public static double angle =.71;
    Toggler AngleTicToggler = new Toggler();


    TrackingWheelIntegrator trackingWheelIntegrator = new TrackingWheelIntegrator();


    LynxDcMotorController ctrl;
    LynxModule module;

    //private Servo Tpusher;

    // private TouchSensor touch;
    // private RevTouchSensor touch;'
    // private DigitalChannel touch;



    @Override
    public void runOpMode() throws InterruptedException {


        trackingWheelIntegrator = new TrackingWheelIntegrator();

        //maping out the robot
        skyStoneDriveBase = new SkyStoneDriveBase();
        skyStoneDriveBase.init(hardwareMap);
        skyStoneDriveBase.resetEncoders();
        skyStoneDriveBase.enableBrake(true);
        skyStoneDriveBase.enablePID();
        Globals.robot=skyStoneDriveBase;
        Globals.driveBase=skyStoneDriveBase;
        shooter = hardwareMap.get(DcMotorEx.class, "shooter");
        intakeTwo = hardwareMap.get(DcMotor.class, "intakeTwo");
        autoDrop = hardwareMap.get(Servo.class, "autoDrop");
        shooterAngle = hardwareMap.get(Servo.class, "shooterAngle");
        intakeLift = hardwareMap.get(Servo.class, "intakeLift");
        WArmL = hardwareMap.get(Servo.class, "WArmL");
        WArmR = hardwareMap.get(Servo.class, "WArmR");
        intake = hardwareMap.get(DcMotor.class, "Intake");
        leftTW = hardwareMap.get(DcMotor.class, "Intake"); // this is also left Tracking wheel
        rightTW = hardwareMap.get(DcMotor.class, "brokport");
        backTW = hardwareMap.get(DcMotor.class, "shooter");
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        Tbooper = hardwareMap.get(Servo.class, "Tbooper");
        module = (LynxModule) hardwareMap.get(LynxModule.class, "Expansion Hub 3");
        ctrl = hardwareMap.get(LynxDcMotorController.class, "Expansion Hub 3");
        //Tpusher= hardwareMap.get(Servo.class, "Tpusher");
        Globals.wobble = hardwareMap.get(Servo.class, "autoDrop");
        Globals.ShooterAngle = hardwareMap.get(Servo.class, "shooterAngle");
        Globals.Shooter = hardwareMap.get(DcMotorEx.class, "shooter");
        Globals.Intake = hardwareMap.get(DcMotor.class, "Intake");
        Globals.IntakeLift = hardwareMap.get(Servo.class, "intakeLift");
        Globals.IntakeTwo = hardwareMap.get(DcMotor.class, "intakeTwo");
        Globals.WArmR = hardwareMap.get(Servo.class, "WArmR");
        Globals.WArm = hardwareMap.get(Servo.class, "WArm");
        Globals.WArmL = hardwareMap.get(Servo.class, "WArmL");
        Globals.Tbooper = hardwareMap.get(Servo.class, "Tbooper");
        Globals.trackingWheelIntegrator = trackingWheelIntegrator;
        Globals.Backsonar = hardwareMap.get(MaxSonarI2CXL.class, "BackSonar");
        Globals.LeftSonar = hardwareMap.get(MaxSonarI2CXL.class, "LeftSonar");
        Globals.RightSonar = hardwareMap.get(MaxSonarI2CXL.class, "RightSonar");
        Globals.odoModule = module;
        Globals.opMode = this;
        Globals.robot.enableBrake(true);
        shooter.setDirection(DcMotorSimple.Direction.REVERSE);
        intake.setDirection(DcMotorSimple.Direction.REVERSE);
        intakeTwo.setDirection(DcMotorSimple.Direction.REVERSE);

        shooter.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        shooter.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        boolean AutomationLastState = false;



        telemetry.setMsTransmissionInterval(20);
        //cmToInch = Globals.RightSonar.getDistanceSync();
        //inch = cmToInch/2.54;
        //telemetry.addData("Dist inch", inch+1);
        telemetry.addData("Status", "Initialized");
        telemetry.update();


        clearEnc();


        buildTrajectory();
        waitForStart();

        while (opModeIsActive()) {

            //curretShooterSpeed = shooter.getVelocity();
            Globals.updateTracking();
          /*telemetry.addData("Shooter Speed:", + curretShooterSpeed);
            telemetry.addData("test", ShooterUpToSpeed);
            telemetry.update();

             */
            if (gamepad2.right_stick_button){
                clearEnc();
                double BackInch = (Globals.Backsonar.getDistanceSync()/2.54)+1;
                trackingWheelIntegrator.setFirstTrackingVal(0,BackInch);
                trackingWheelIntegrator.setHeading(0);

                System.out.println("BackSonar: " + BackInch);
            }
            if (gamepad2.left_bumper) {         //If button is pressed Auto aline will run. if not normaly gamepad works
                if (AutomationLastState == false) {
                    clearEnc();
                    //double LeftInch = (Globals.LeftSonar.getDistanceSync()/2.54)+1;
                    trackingWheelIntegrator.setFirstTrackingVal(0,0);
                    Globals.ShooterAngle.setPosition(.75);
                    Globals.Shooter.setVelocity(1100);
                    Globals.robot.enablePID();
                    buildTrajectoryPS();

                }
                AutomationLastState = true;
                trajectory.followInteration();

            }
            else if (gamepad1.left_bumper) {
                if (AutomationLastState == false) {
                    buildTrajectory();
                }
                AutomationLastState = true;
                trajectory.followInteration();

            }
            else {
                runGamepad();
                if (AutomationLastState == true) {
                    AutomationLastState = false;
                    Globals.robot.enableBrake(true);
                    Globals.robot.disablePID();
                    Globals.Shooter.setPower(0);
                    Globals.ShooterAngle.setPosition(.9);
                    trajectory.reset();

                }
            }
        }
    }

    void runGamepad() {
            boolean xtakeOn = false;
            boolean placeHolderOneTick = false;

            MecanumDrive.cartesian(Globals.robot,
                    -gamepad1.left_stick_y, // Main
                    gamepad1.left_stick_x , // Strafe
                    gamepad1.right_stick_x * .85); // Turn

            /* TeleOp Shooter Angle
            if (gamepad1.dpad_right) {
                shooterAngle.setPosition(.78);
            }
            if (gamepad1.dpad_left) {
                shooterAngle.setPosition(.9);
            }

             */
            if (gamepad1.a) {
                intake.setPower(-1);
                intakeTwo.setPower(1);

            }
            if (gamepad1.b) {
                intake.setPower(0);
                intakeTwo.setPower(0);
            }
            if (gamepad1.dpad_up) {
                intakeLift.setPosition(.66);
            }
            if (gamepad1.dpad_down) {
                intakeLift.setPosition(1);
            }
           /* if (gamepad2.dpad_left) {
                Globals.ShooterAngle.setPosition(.8);

            }
            if (gamepad2.dpad_right) {
                Globals.ShooterAngle.setPosition(.9);
            }

            */
            if (gamepad2.b) {
                Globals.Shooter.setPower(0);
                Globals.ShooterAngle.setPosition(.9);
                ShooterUpToSpeed = false;
            }
            if (gamepad2.right_bumper) {
                //Globals.Tbooper.setPosition(.3);
            }
            else {
                Globals.Tbooper.setPosition(.18);
            }
            while (gamepad2.a) {
              /*curretShooterSpeed = shooter.getVelocity();
              telemetry.addData("Shooter Speed:", + curretShooterSpeed);
              telemetry.addData("test", ShooterUpToSpeed);
              telemetry.update();
              shooter.setVelocity(1700);
              if (curretShooterSpeed > 1600) {
                  ShooterUpToSpeed = true;
              }
              if (ShooterUpToSpeed = true) {
                  Tbooper.setPosition(18);
                  ShooterUpToSpeed = false;
              }

               */

                shooter.setVelocity(1050);
                Globals.ShooterAngle.setPosition(.72);
                angle = .75;
            }
           /* if (gamepad2.right_bumper) {
                Globals.Tbooper.setPosition(.28);
            }
            if (gamepad2.left_bumper) {
                Globals.Tbooper.setPosition(.15);
            }

            */
            if (gamepad2.x) {
                WArmL.setPosition(.45);
                WArmR.setPosition(.45);
            }
            if (gamepad2.y) {
                WArmL.setPosition(1);
                WArmR.setPosition(1);
            }
            if (gamepad2.dpad_down) {
                Globals.WArm.setPosition(.35);
            }
            if (gamepad2.dpad_left) {
                Globals.WArm.setPosition(.5);
            }
            if (gamepad2.dpad_right) {
                Globals.robot.disablePID();
            }
            if (gamepad2.dpad_up) {
                Globals.WArm.setPosition(.8);
            }
            if (gamepad1.right_bumper) {
                intakeTwo.setPower(-1);
                intake.setPower(1);
                xtakeOn = true;
            }
            if (!gamepad1.right_bumper && (xtakeOn == true)){
                intake.setPower(0);
                intakeTwo.setPower(0);

            }
            if (gamepad2.start) {
                Globals.Shooter.setPower(-1);
            }
            /*if (gamepad1.left_bumper) {
                intake.setPower(0);
                intakeTwo.setPower(0);
                sleep(100);
                shooter.setVelocity(1050);
                shooterAngle.setPosition(.67);
                Tbooper.setPosition(.17);
                //Tpusher.setPosition(.77);
                sleep(1000);
                Tbooper.setPosition(.28);//shoot one
                sleep(75);
                Tbooper.setPosition(.15);
                sleep(200);
                Tbooper.setPosition(.28);//shoot two
                sleep(75);
                Tbooper.setPosition(.15);
                sleep(200);
                Tbooper.setPosition(.28);//shoot three
                sleep(150);
                Tbooper.setPosition(.15);
                //Tpusher.setPosition(1);
                shooterAngle.setPosition(.9);
                sleep(100);
                shooter.setPower(0);



            }

             */
            if(AngleTicToggler.shouldToggle(gamepad2.left_bumper )){
                angle = angle+.1;
            }
            if(AngleTicToggler.shouldToggle(gamepad2.right_bumper)){
                angle = angle-.1;
            }

           /*
            if (gamepad2.left_trigger > .5) {
                angle = .77;
            }
            if (gamepad2.right_trigger > .5 ) {
                angle = .71;
            }

            */

    }
     public void buildTrajectory() {

          trajectory = new StateMTrajectory.Builder()

          /*.addMovement(new StateMPointApproach.Builder()
               .setTargetPosition(-26,58)
               .setMaxPower(1)
               .setXyGain(.08)
               .setTargetHeading(0) //fix Wrap around heading by checking how many 360s are in the heading
               .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
               .setMaxTurnPower(0.8)
               .setMovementThresh(1)
               .setHeadingThreshold(1)
               .stopMotorsOnDone(true)
               .build())

           */
          .addMovement(new StateMShooterShotThree()) // (.9))
          .build();



    }
     public void buildTrajectoryPS() {

         trajectory = new StateMTrajectory.Builder()
// BLUE
                 .addMovement(new StateMWaypoint.Builder() // First Stright movment to Target position
                         .setTargetPosition(25, 37)
                         .setTargetHeading(-40)
                         .setSpeed(1)
                         .setTransThreshMethod(StateMWaypoint.TranslationThreshMethod.Y_ONLY)
                         .setMovementThresh(1)
                         .setHeadingThreshold(0)
                         .build())
                 .addMovement(new StateMPointApproach.Builder() //Ps one
                         .setTargetPosition(43,58)
                         .setMaxPower(1)
                         .setXyGain(.08)
                         .setTargetHeading(2)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.8)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
                 .addMovement(new SMPSOverHeadOne())
                 .addMovement(new StateMPointApproach.Builder() // Ps Two
                         .setTargetPosition(45.5,58)
                         .setMaxPower(1)
                         .setXyGain(.08)
                         .setTargetHeading(-5)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.8)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
                 .addMovement(new SMPSOverHeadTwo())
                 .addMovement(new StateMPointApproach.Builder()// Ps Three
                         .setTargetPosition(50,58)
                         .setMaxPower(1)
                         .setXyGain(.08)
                         .setTargetHeading(-5)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.8)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
                 .addMovement(new SMPSOverHeadThree())
                 .addMovement(new StateMPointApproach.Builder()// Ps Three
                         .setTargetPosition(49,70)
                         .setMaxPower(1)
                         .setXyGain(.08)
                         .setTargetHeading(0)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.8)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
                 .build();






// RED
              /*   .addMovement(new StateMWaypoint.Builder() // First Stright movment to Target position
                         .setTargetPosition(-25, 37)
                         .setTargetHeading(40)
                         .setSpeed(1)
                         .setTransThreshMethod(StateMWaypoint.TranslationThreshMethod.Y_ONLY)
                         .setMovementThresh(1)
                         .setHeadingThreshold(0)
                         .build())
                 .addMovement(new StateMPointApproach.Builder() //Ps one
                        .setTargetPosition(-39,56)
                        .setMaxPower(1)
                        .setXyGain(.08)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                 .addMovement(new SMPSOverHeadOne())
                 .addMovement(new StateMPointApproach.Builder() // Ps Two
                        .setTargetPosition(-45.5,56)
                        .setMaxPower(1)
                        .setXyGain(.08)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                 .addMovement(new SMPSOverHeadTwo())
                 .addMovement(new StateMPointApproach.Builder()// Ps Three
                         .setTargetPosition(-51.5,56)
                         .setMaxPower(1)
                         .setXyGain(.08)
                         .setTargetHeading(0)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.8)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
                 .addMovement(new SMPSOverHeadThree())
                 .addMovement(new StateMPointApproach.Builder()// Ps Three
                         .setTargetPosition(-49,70)
                         .setMaxPower(1)
                         .setXyGain(.08)
                         .setTargetHeading(0)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.8)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
                 .build();




               */



     }
     public void ManShootingStateM() {
         trajectory = new StateMTrajectory.Builder()
                 .addMovement(new StateMShooterShotThree()) // (.9))
                 .build();
     }
     void clearEnc()
     {
         ctrl.setMotorMode(0, DcMotor.RunMode.STOP_AND_RESET_ENCODER);
         ctrl.setMotorMode(1, DcMotor.RunMode.STOP_AND_RESET_ENCODER);
         ctrl.setMotorMode(2, DcMotor.RunMode.STOP_AND_RESET_ENCODER);


         ctrl.setMotorMode(0, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
         ctrl.setMotorMode(1, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
         ctrl.setMotorMode(2, DcMotor.RunMode.RUN_WITHOUT_ENCODER);

     }
     public static double GetShootingAngle() {
        Globals.angle = angle;
        return Globals.angle;
     }
}



