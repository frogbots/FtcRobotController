package org.firstinspires.ftc.teamcode;

// import
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.exception.TargetPositionNotSetException;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.Servo;
// import com.qualcomm.hardware.rev.RevTouchSensor;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;


@TeleOp
public class IKnowTheWay extends LinearOpMode {


    // declaring robot parts
    private BNO055IMU imu;
    private DcMotor frontLeft;
    private DcMotor frontRight;
    private DcMotor backLeft;
    private DcMotor backRight;
    private Servo autoDrop;
    private Servo shooterAngle;
    private Servo transferLift;
    // private DcMotor intake;
    private DcMotor rightTW;
    private DcMotor leftTW;
    private DcMotor backTW;
    private DcMotor shooter;
    // private TouchSensor touch;
    // private RevTouchSensor touch;'
    private DigitalChannel touch;




    @Override
    public void runOpMode() throws InterruptedException {
        //maping out the robot
        frontLeft= hardwareMap.get(DcMotor.class, "frontLeft");
        frontRight= hardwareMap.get(DcMotor.class, "frontRight");
        backLeft= hardwareMap.get(DcMotor.class, "backLeft");
        backRight= hardwareMap.get(DcMotor.class, "backRight");
        shooter= hardwareMap.get(DcMotor.class, "shooter");
        autoDrop = hardwareMap.get(Servo.class, "autoDrop");
        shooterAngle = hardwareMap.get(Servo.class,"shooterAngle");
        transferLift = hardwareMap.get(Servo.class,"transferLift");
        // intake= hardwareMap.get(DcMotor.class, "intake");
        // touch = hardwareMap.get(DigitalChannel.class, "revts");
        leftTW= hardwareMap.get(DcMotor.class, "leftTW");
        rightTW= hardwareMap.get(DcMotor.class, "rightTW");
        backTW= hardwareMap.get(DcMotor.class, "backTW");
        imu=hardwareMap.get(BNO055IMU.class, "imu");


        // reset encoder counts kept by motors.
        frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        frontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        frontRight.setDirection(DcMotor.Direction.REVERSE);
        backRight.setDirection(DcMotor.Direction.REVERSE);

        rightTW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightTW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftTW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftTW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backTW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backTW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);


        // end of initilzation
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        waitForStart();

        // TelepOP
        double Power = 1.0;
        boolean servoIsTrue = true;
        boolean shooterIsOn = false;
        int state = 0;
        // back encoder counts for the tracking wheels
        double bCountsTW;
        // Left encoder counts for the tracking wheels
        double lCountsTW;
        // Right encoder counts for the tracking wheels
        double rCountsTW;
        // Targetposition of X
        double aX = 0;
        double aX1 = 0;
        double aX2 = 0;
        double aX3 = 0;
        double aX4 = 0;
        double aX5 = 0;
        double lPower = 0;
        double rPower = 0;


        // Target position of Y
        double aY = 0;
        boolean droppedWobble = false;
        char tgPosition = 'O';




        while (opModeIsActive()) {

            telemetry.addData("State:",  +state);
            // telematry for encoders on the phone
            bCountsTW = backTW.getCurrentPosition()+1;
            lCountsTW = leftTW.getCurrentPosition()+1;
            rCountsTW = rightTW.getCurrentPosition()+1;
            telemetry.addData("Back:",  +bCountsTW);
            System.out.println("Back Tracking Wheel:");
            System.out.println(bCountsTW);
            telemetry.addData("Left Counts:", + lCountsTW);
            System.out.println("Left Tracking Wheel:");
            System.out.println(lCountsTW);
            telemetry.addData("Right Counts", + rCountsTW);
            System.out.println("Right Tracking Wheel:");
            System.out.println(rCountsTW);
            telemetry.addData("Power:", + Power);
            //System.out.println("Left Power");
            //System.out.println(lPower);
            //System.out.println("Right Power");
            //System.out.println(rPower);
            telemetry.addData( "Target Postion", + tgPosition);
            System.out.println("Target Position");
            System.out.println(tgPosition);
            System.out.println("Target encoder counts:");
            System.out.println(aX);
            System.out.println("Current state:");
            System.out.println(state);
            telemetry.update();

            // TeleOp Auto wobble goal drop testing
            if (gamepad1.dpad_down)autoDrop.setPosition(1);
            if (gamepad1.dpad_up)autoDrop.setPosition(.5);

            // TeloOp Shooter Stuff
            if (gamepad2.x) {
                if (shooterIsOn = false); {
                    shooter.setPower(1);
                    shooterIsOn = true;
                }
            }
            if (gamepad2.x) {
                if (shooterIsOn = true); {
                    shooter.setPower(0);
                    shooterIsOn = false;
                }
            }

            // TeleOp Shooter Angle
            if (gamepad2.dpad_up) {
                shooterAngle.setPosition(.9);
            }
            if (gamepad2.dpad_down) {
                shooterAngle.setPosition(.79);
            }
            if (gamepad2.dpad_left) {
                shooterAngle.setPosition(.8);
            }
            if (gamepad2.dpad_right) {
                shooterAngle.setPosition(.78);
            }

            if (gamepad2.a) {
                transferLift.setPosition(.83);

            }
            if (gamepad2.b) {
                transferLift.setPosition(.4);
            }

            //State machine
            switch (state) {
                case 0:
                    // stoped
                    Power = 0;
                    if (gamepad1.a) {
                        aX = 62*1700;
                        aX1 = 93500;
                        aX2 = 32000;
                        state = 1;
                    }

                    if (gamepad1.b) {
                        aX = 88*1700;
                        aX1 = 93500;
                        aX2 = 32000;
                        state = 1;
                    }

                    if (gamepad1.x) {
                    aX = 112*1700;
                    aX1 = 93500;
                    aX2 = 32000;
                    state = 1;
                    }

                    frontLeft.setPower(Power);
                    frontRight.setPower(Power);
                    backLeft.setPower(Power);
                    backRight.setPower(Power);
                    break;

                case 1:
                    // move Forward
                    tgPosition = 'A';
                    Power = 1;
                    if (Power > 0) {
                            Power = 0.1 + (aX + lCountsTW)/aX;
                            rPower = Power;
                            lPower = Power;
                            frontLeft.setPower(lPower);
                            frontRight.setPower(rPower);
                            backLeft.setPower(lPower);
                            backRight.setPower(rPower);
                        if (lCountsTW>rCountsTW) {
                            frontLeft.setPower(lPower+.1);
                            backLeft.setPower(lPower+.1);
                        }
                        if (rCountsTW>lCountsTW) {
                            frontRight.setPower(rPower+.1);
                            backRight.setPower(rPower+.1);
                        }
                            //if (bCountsTW>5) {
                            //    rPower=Power*.7;
                            //    frontRight.setPower(rPower);
                            //    backRight.setPower(rPower);
                            //}


//                            if (bCountsTW<-5) {
//                                lPower =Power*.7;
//                                frontLeft.setPower(lPower);
//                                backLeft.setPower(lPower);
//                            }
                            System.out.println("left Power");
                            System.out.println(lPower);

                            System.out.println("Right Power");
                            System.out.println(rPower);
                            if (lCountsTW < -aX) {
                                Power = 0;
                                state = 2;
                            }
                    }
                 break;

                case 2:
                    // drop Wobble Goal
                    Power = 0;
                    frontLeft.setPower(Power);
                    frontRight.setPower(Power);
                    backLeft.setPower(Power);
                    backRight.setPower(Power);
                    sleep(1000);
                    autoDrop.setPosition(.5);
                    sleep(1000);
                    droppedWobble = true;
                    if (droppedWobble = true); state = 3;
                    break;

                case 3:
                    // move back
                    Power = 1;
                    if (Power > 0) {
                        Power = -0.1 + (aX1 + lCountsTW)/aX1;
                        frontLeft.setPower(Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(Power);
                        if (lCountsTW>rCountsTW) {
                            frontLeft.setPower(Power+.1);
                            backLeft.setPower(Power+.1);
                        }
                        if (rCountsTW>lCountsTW) {
                            frontRight.setPower(Power+.1);
                            backRight.setPower(Power+.1);
                        }
                        if (lCountsTW > -aX1) {
                            Power = 0;
                            state = 4;
                        }
                    }
                    break;

                case 4:
                    // move to shoot
                    Power = 1;
                    if (Power > 0) {
                        Power = -0.1 + (aX2 + bCountsTW)/aX2;
                        frontLeft.setPower(-Power);
                        frontRight.setPower(Power);
                        backLeft.setPower(Power);
                        backRight.setPower(-Power);
                        if (lCountsTW > -aX2) {
                            Power = 0;
                            state = 7;
                        }
                    }
                    break;

                case 5:
                    Power = 0;
                    frontLeft.setPower(-Power);
                    frontRight.setPower(Power);
                    backLeft.setPower(Power);
                    backRight.setPower(-Power);
                    break;




                default:
                    Power = 0;
                    frontLeft.setPower(Power);
                    frontRight.setPower(Power);
                    backLeft.setPower(Power);
                    backRight.setPower(Power);
                    break;
            }



        }
    }


}

