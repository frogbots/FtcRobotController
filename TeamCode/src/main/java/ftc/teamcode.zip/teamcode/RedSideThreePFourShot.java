package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.lynx.LynxDcMotorController;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.MovingStatistics;

import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvInternalCamera;

import control.AcceleratedGain;
import robotComponents.drivebase.SkyStoneDriveBase;
import trajectory.IntakeDown;
import trajectory.IntakeDownSlow;
import trajectory.IntakeDownSlowTwo;
import trajectory.IntakeDownTwo;
import trajectory.IntakeOff;
import trajectory.PickUpWobbleGoal;
import trajectory.PointApproach;
import trajectory.PrepareForTeleop;
import trajectory.RiseWG;
import trajectory.ShootPSOne;
import trajectory.ShootPSThree;
import trajectory.ShootPSTwo;
import trajectory.ShooterShotThree;
import trajectory.ShooterShotThreefar;
import trajectory.SleepAction;
import trajectory.Trajectory;
import trajectory.Waypoint;
import trajectory.WobbleDeployAction;
import trajectory.WobbleGoalDropTwo;
import drivers.MaxSonarI2CXL;


@Autonomous (preselectTeleOp="frogTeleOp")
public class RedSideThreePFourShot extends LinearOpMode
{

    MovingStatistics movingStatistics = new MovingStatistics(300);

    long startLoop = 0;

    private DcMotor shooter;

    private DcMotorEx FL;
    private DcMotorEx FR;
    private DcMotorEx RL;
    private DcMotorEx RR;
    double DropX;
    double DropY;
    double DropHeading;
    double DropHeadingTwo;
    double DropXTwo;
    double DropYTwo;
    double FirstFeildMovementX;
    double FirstFeildMovmentY;
    double WaypointXTwoD;
    double WaypointYTwoD;
    double ShootY;
    double ShootX;
    double ShootH;
    double cmToInch = 0;
    public double inch = 0;
    OpenCvCamera phoneCam;
    public static boolean RingStack;


    TrackingWheelIntegrator trackingWheelIntegrator = new TrackingWheelIntegrator();

    LynxDcMotorController ctrl;
    LynxModule module;

    SkyStoneDriveBase skyStoneDriveBase;

    Trajectory trajectory;




    DropPositions position = DropPositions.B;

    void SetDropPositions(){
        if (position == DropPositions.A) {
            DropX = -5;
            DropY = 64;
            DropHeading = -32;
            DropHeadingTwo = 135;
            FirstFeildMovementX = -5;
            FirstFeildMovmentY = 30;
            DropXTwo = -17;
            DropYTwo = 67;
            WaypointXTwoD = -20;
            WaypointYTwoD = 30;
            RingStack = false;
            ShootY = DropYTwo;
            ShootX = DropXTwo;
            ShootH = DropHeadingTwo;
        }
        else if (position == DropPositions.B) {
            DropX = -20;
            DropY = 89;
            DropHeading = 5;
            DropHeadingTwo = 180;
            FirstFeildMovementX = -5;
            FirstFeildMovmentY = 50;
            DropXTwo = -32;
            DropYTwo = 82;
            WaypointXTwoD = -25;
            WaypointYTwoD = 40;
            RingStack = true;
            ShootX = -24;
            ShootY = 50;
            ShootH = 0;
        }
        else if (position == DropPositions.C) {
            DropX = -5; // 5
            DropY = 113;
            DropHeading = -28.3;
            DropHeadingTwo = 177;
            FirstFeildMovementX = -5; //5
            FirstFeildMovmentY = 70;
            DropXTwo = -10;
            DropYTwo = 107;
            WaypointXTwoD = -5;
            WaypointYTwoD = 70;
            RingStack = true;
            ShootX = -24;
            ShootY = 50;
            ShootH = 0;
        }
    }

    @Override
    public void runOpMode() throws InterruptedException
    {

        trackingWheelIntegrator = new TrackingWheelIntegrator();

        module = (LynxModule) hardwareMap.get(LynxModule.class, "Expansion Hub 3");
        ctrl = hardwareMap.get(LynxDcMotorController.class, "Expansion Hub 3");

        skyStoneDriveBase = new SkyStoneDriveBase();
        skyStoneDriveBase.init(hardwareMap);
        skyStoneDriveBase.resetEncoders();
        skyStoneDriveBase.enableBrake(true);
        skyStoneDriveBase.enablePID();
        Globals.robot=skyStoneDriveBase;
        Globals.driveBase=skyStoneDriveBase;

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        phoneCam = OpenCvCameraFactory.getInstance().createInternalCamera(OpenCvInternalCamera.CameraDirection.FRONT, cameraMonitorViewId);
        RingDetectionRed RingPipline = new RingDetectionRed();
        phoneCam.setPipeline(RingPipline);
        phoneCam.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener()
        {
            @Override
            public void onOpened()
            {
                phoneCam.setViewportRenderingPolicy(OpenCvCamera.ViewportRenderingPolicy.OPTIMIZE_VIEW);
                phoneCam.startStreaming(320, 240, OpenCvCameraRotation.SIDEWAYS_LEFT);
            }
        });




        telemetry.setMsTransmissionInterval(50);

        Globals.RightSonar = hardwareMap.get(MaxSonarI2CXL.class, "RightSonar");
        Globals.opMode = this;
        Globals.trackingWheelIntegrator = trackingWheelIntegrator;
        Globals.odoModule = module;
        Globals.wobble = hardwareMap.get(Servo.class, "autoDrop");
        Globals.ShooterAngle = hardwareMap.get(Servo.class, "shooterAngle");
        Globals.Shooter= hardwareMap.get(DcMotorEx.class,"shooter");
        Globals.Intake=hardwareMap.get(DcMotor.class,"Intake");
        Globals.IntakeTwo=hardwareMap.get(DcMotor.class, "intakeTwo");
        Globals.WArmR=hardwareMap.get(Servo.class, "WArmR");
        Globals.WArmL=hardwareMap.get(Servo.class, "WArmL");
        Globals.WArm=hardwareMap.get(Servo.class, "WArm");
        Globals.Tbooper= hardwareMap.get(Servo.class, "Tbooper");
        //Globals.Tpusher= hardwareMap.get(Servo.class, "Tpusher");
        Globals.IntakeLift= hardwareMap.get(Servo.class, "intakeLift");

        Globals.Shooter.setDirection(DcMotor.Direction.REVERSE);

        /*Globals.robot.frontLeft = RL;
        Globals.robot.frontRight = RR;
        Globals.robot.rearLeft = FL;
        Globals.robot.rearRight = FR;

         */





        Globals.ShooterAngle.setPosition(1);
        Globals.wobble.setPosition(1);
        //Globals.IntakeLift.setPosition(1);
        Globals.Tbooper.setPosition(.15);
        Globals.IntakeLift.setPosition(.6);
        //Globals.Tpusher.setPosition(.77);

        telemetry.setMsTransmissionInterval(20);
        cmToInch = Globals.RightSonar.getDistanceSync();
        inch = cmToInch/2.54;
        telemetry.addData("Dist inch", inch+1);
        telemetry.addData("Position", RingPipline.GetPosition());
        telemetry.update();

        Globals.inch = inch;

        trackingWheelIntegrator.setFirstTrackingVal(-inch,0);

        clearEnc();




        while (!isStopRequested() && !isStarted()) {
            position = RingPipline.GetPosition();
            telemetry.addData("Position", RingPipline.GetPosition());
            telemetry.addData("Dist inch", inch+1);
            telemetry.update();
        }
        SetDropPositions();
        if (position == DropPositions.A) {
            buildTrajectoryA();
        }
        if (position == DropPositions.B) {
            buildTrajectoryB();
        }
        if (position == DropPositions.C) {
            buildTrajectoryC();
        }
        trajectory.follow();
    }


    void clearEnc()
    {
        ctrl.setMotorMode(0, DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        ctrl.setMotorMode(1, DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        ctrl.setMotorMode(2, DcMotor.RunMode.STOP_AND_RESET_ENCODER);


        ctrl.setMotorMode(0, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ctrl.setMotorMode(1, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ctrl.setMotorMode(2, DcMotor.RunMode.RUN_WITHOUT_ENCODER);

    }

    public void buildTrajectoryA()
    {
        trajectory = new Trajectory.Builder()

                 .addMovement(new Waypoint.Builder() // First Stright movment to Target position
                        .setTargetPosition(FirstFeildMovementX, FirstFeildMovmentY )
                        .setTargetHeading(0)
                        .setSpeed(1)
                        .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .build())
                .addMovement(new PointApproach.Builder() //Final Target position movment and Drop First Wobble goal
                        .setTargetPosition(DropX,DropY)
                        .setMaxPower(0.95)
                        .setXyGain(.06)
                        .setTargetHeading(DropHeading)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.6)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new SleepAction(300))
                .addMovement(new WobbleDeployAction()) // Drop Wobble goal
                .addMovement(new SleepAction(700))
                /*.addMovement(new PointApproach.Builder() //Move to Shoot
                        .setTargetPosition(-17.7,58)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(5)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShooterShotThree()) //Shoot 3 into goal.

                 */
                // if we shoot at the power shoot this is where we would put them.
                 .addMovement(new PointApproach.Builder() //Move to Shoot PS1 right
                        .setTargetPosition(-42,62) //-41
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(1)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSOne())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS2 middle
                        .setTargetPosition(-43,62) //43
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(5)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(1)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSTwo())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS3 left
                        .setTargetPosition(-44,62) //45
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(10)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(1)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSThree())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(-36,27)
                        .setMaxPower(1)
                        .setXyGain(.06)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                       .setTargetPosition(-30,27)
                       .setMaxPower(1)
                       .setXyGain(.04)
                       .setTargetHeading(0)
                       .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                       .setMaxTurnPower(0.45)
                       .setMovementThresh(1)
                       .setHeadingThreshold(2)
                       .stopMotorsOnDone(true)
                       .build())
               .addMovement(new RiseWG())
               .addMovement(new SleepAction(100))
               .addMovement(new PickUpWobbleGoal()) //PickUpWobbleGoal
               .addMovement(new SleepAction(200))
               .addMovement(new PointApproach.Builder() //Move to Drop off point.
                       .setTargetPosition(DropXTwo,DropYTwo)
                       .setMaxPower(0.95)
                       .setXyGain(.08)
                      .setTargetHeading(DropHeadingTwo)
                       .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                       .setMaxTurnPower(0.8)
                       .setMovementThresh(1)
                       .setHeadingThreshold(2)
                       .stopMotorsOnDone(true)
                       .build())
               .addMovement(new WobbleGoalDropTwo()) // Drop Wobble goal
               .addMovement(new SleepAction(200))
                /* // bounce back code
               .addMovement(new PointApproach.Builder() //Move to Park position for bounce back
                         .setTargetPosition(-24,70)
                         .setMaxPower(1)
                         .setXyGain(.1)
                         .setTargetHeading(0)
                         .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                         .setMaxTurnPower(0.9)
                         .setMovementThresh(1)
                         .setHeadingThreshold(2)
                         .stopMotorsOnDone(true)
                         .build())
               .addMovement(new IntakeDownTwo())
               .addMovement(new Waypoint.Builder()
                        .setTargetPosition(-21, 100 )
                        .setTargetHeading(0)
                        .setSpeed(1)
                        .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .build())
               .addMovement(new PointApproach.Builder() //Go for bounce back
                        .setTargetPosition(-21,123)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(90)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
               .addMovement(new PointApproach.Builder() //Go for bounce back
                        .setTargetPosition(-50,123)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(90)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
               .addMovement(new PointApproach.Builder() //Move to Shoot
                        .setTargetPosition(-23,58)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(0)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
               .addMovement(new IntakeOff())
               .addMovement(new ShooterShotThree()) //Shoot 3 into goal.

                 */
               .addMovement(new PointApproach.Builder() //Move to Park
                        .setTargetPosition(-24,70)
                        .setMaxPower(1)
                        .setXyGain(.1)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.9)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
               .addMovement(new PrepareForTeleop())
               .addMovement(new SleepAction(200))


        .build();
    }
    public void buildTrajectoryB()
    {
        trajectory = new Trajectory.Builder()

                .addMovement(new Waypoint.Builder() // First Stright movment to Target position
                        .setTargetPosition(FirstFeildMovementX, FirstFeildMovmentY )
                        .setTargetHeading(0)
                        .setSpeed(1)
                        .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .build())
                .addMovement(new PointApproach.Builder() //Final Target position movment and Drop Wobble goal
                        .setTargetPosition(DropX,DropY)
                        .setMaxPower(0.95)
                        .setXyGain(.06)
                        .setTargetHeading(DropHeading)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.6)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleDeployAction()) // Drop Wobble goal
                .addMovement(new SleepAction(700))
                /*.addMovement(new PointApproach.Builder() //Move to Shoot
                        .setTargetPosition(-17.7,58)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(5)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShooterShotThree()) //Shoot 3 into goal.

                 */
                // if we shoot at the power shoot this is where we would put them.
                .addMovement(new PointApproach.Builder() //Move to Shoot PS1 right
                        .setTargetPosition(-41,62) //-41
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSOne())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS2 middle
                        .setTargetPosition(-42,62) //43
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(5)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSTwo())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS3 left
                        .setTargetPosition(-44.5,62) //45
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(10)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSThree())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(-36,27)
                        .setMaxPower(1)
                        .setXyGain(.06)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(-30,27)
                        .setMaxPower(1)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new RiseWG())
                .addMovement(new SleepAction(100))
                .addMovement(new PickUpWobbleGoal()) //PickUpWobbleGoal\
                .addMovement(new IntakeDownTwo())
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(-24,27)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new SleepAction(1500))
                .addMovement(new ShooterShotThreefar())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Drop off point.
                        .setTargetPosition(DropXTwo,DropYTwo)
                        .setMaxPower(0.95)
                        .setXyGain(.08)
                        .setTargetHeading(DropHeadingTwo)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleGoalDropTwo()) // Drop Wobble goal
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Park
                        .setTargetPosition(-24,70)
                        .setMaxPower(1)
                        .setXyGain(.1)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.9)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new PrepareForTeleop())
                .addMovement(new SleepAction(200))


                .build();
    }
    public void buildTrajectoryC()
    {
        trajectory = new Trajectory.Builder()

                .addMovement(new Waypoint.Builder() // First Stright movment to Target position
                        .setTargetPosition(FirstFeildMovementX, FirstFeildMovmentY )
                        .setTargetHeading(0)
                        .setSpeed(1)
                        .setTransThreshMethod(Waypoint.TranslationThreshMethod.Y_ONLY)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .build())
                .addMovement(new PointApproach.Builder() //Final Target position movment and Drop Wobble goal
                        .setTargetPosition(DropX,DropY)
                        .setMaxPower(0.95)
                        .setXyGain(.06)
                        .setTargetHeading(DropHeading)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.6)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleDeployAction()) // Drop Wobble goal
                .addMovement(new SleepAction(700))
                /*.addMovement(new PointApproach.Builder() //Move to Shoot
                        .setTargetPosition(-17.7,58)
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(5)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(0)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShooterShotThree()) //Shoot 3 into goal.

                 */
                // if we shoot at the power shoot this is where we would put them.
                .addMovement(new PointApproach.Builder() //Move to Shoot PS1 right
                        .setTargetPosition(-40,62) //-41
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSOne())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS2 middle
                        .setTargetPosition(-43,62) //43
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(5)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSTwo())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Shoot PS3 left
                        .setTargetPosition(-44.5,62) //45
                        .setMaxPower(0.85)
                        .setXyGain(.04)
                        .setTargetHeading(10)                                        // Movement to shot 3 into High goal
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new ShootPSThree())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(-36,27)
                        .setMaxPower(1)
                        .setXyGain(.06)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new PointApproach.Builder() // Go for second wobble goal .
                        .setTargetPosition(-30,27)
                        .setMaxPower(1)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.45)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new RiseWG())
                .addMovement(new SleepAction(100))
                .addMovement(new PickUpWobbleGoal()) //PickUpWobbleGoal
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(-24,25.5)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new IntakeDown())
                .addMovement(new SleepAction(1000))
                .addMovement(new IntakeDownSlow())
                .addMovement(new SleepAction(2000))
                .addMovement(new ShooterShotThreefar())
                .addMovement(new IntakeDownSlowTwo())
                .addMovement(new PointApproach.Builder() //pick up rings
                        .setTargetPosition(-24,27)
                        .setMaxPower(.95)
                        .setXyGain(.04)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())

                .addMovement(new SleepAction(500))
                .addMovement(new IntakeDownTwo())
                .addMovement(new SleepAction(1000))
                .addMovement(new ShooterShotThreefar())
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Drop off point.
                        .setTargetPosition(DropXTwo,DropYTwo)
                        .setMaxPower(0.95)
                        .setXyGain(.08)
                        .setTargetHeading(DropHeadingTwo)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.8)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new WobbleGoalDropTwo()) // Drop Wobble goal
                .addMovement(new SleepAction(200))
                .addMovement(new PointApproach.Builder() //Move to Park
                        .setTargetPosition(-24,70)
                        .setMaxPower(1)
                        .setXyGain(.1)
                        .setTargetHeading(0)
                        .setHeadingDynamicGain(new AcceleratedGain(.012, 0.0004))
                        .setMaxTurnPower(0.9)
                        .setMovementThresh(1)
                        .setHeadingThreshold(2)
                        .stopMotorsOnDone(true)
                        .build())
                .addMovement(new PrepareForTeleop())
                .addMovement(new SleepAction(200))


                .build();
    }
}
